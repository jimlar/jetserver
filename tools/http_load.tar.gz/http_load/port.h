/* port.h - portability defines */

#if defined(__FreeBSD__)
# define FreeBSD
# define ARCH "FreeBSD"
#else
# if defined(linux)
#  define Linux
#  define ARCH "Linux"
# else
#  if defined(sun)
#   define Solaris
#   define ARCH "Solaris"
#  else
#   define UNKNOWN
#   define ARCH "UNKNOWN"
#  endif
# endif
#endif

#ifdef FreeBSD
# define HAVE_SRANDOMDEV
#endif

#ifdef Linux
#endif

#ifdef Solaris
#endif
